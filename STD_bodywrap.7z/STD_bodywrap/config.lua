-- README.MD // USE TriggerEvent("STD:ReviveOnRemove") to remove Config.prop after revive.

Config = {}

Config.Item = 'bodywrap' -- Item Use
Config.prop = 'prop_water_corpse_01' --Props

Config.Needcop = 5  -- Needed Police

--Progressbar
Config.progress = 'mythic_progbar:client:progress' 
Config.timeprogress = 7000 
Config.textprogress = 'กำลังมัดและปิดตา' 

--Animation
Config.animDict = 'anim@gangops@facility@servers@bodysearch@' 
Config.anim = 'player_search' 